class PagesController < ApplicationController
  layout 'no-sidebar'
  def me
  end
end
